import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
public class BMI extends JFrame
{
    JLabel heightLabel = new JLabel();
    JLabel weightLabel = new JLabel();
    JLabel BMILabel = new JLabel(); 
    JLabel feetLabel = new JLabel();
    JLabel inchLabel = new JLabel();
    JLabel poundLabel = new JLabel();
    
    JTextField heightTextField = new JTextField();
    JTextField weightTextField = new JTextField();
    JTextField BMITextField = new JTextField();
    JTextField feetTextField = new JTextField();
        
    JButton computeButton = new JButton();
    JButton clearButton = new JButton();
    JButton exitButton = new JButton();
        
    public BMI()
    {
        setTitle("BMI Calculator");
        setSize(320, 130);
        
        addWindowListener(new WindowAdapter()
        {
            public void windowClosing( WindowEvent e)
            {
                exitForm(e);
            }
        });

        getContentPane().setLayout(new GridBagLayout());
        GridBagConstraints gridConstraints = new GridBagConstraints();
        
        heightLabel.setText("Height:");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 0;
        getContentPane().add(heightLabel, gridConstraints);
    
        weightLabel.setText("Weight:");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 1;
        getContentPane().add(weightLabel, gridConstraints);
        
        BMILabel.setText("BMI:");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 2;
        getContentPane().add(BMILabel, gridConstraints);

        computeButton.setText("Compute BMI");
        gridConstraints.gridx = 0;
        gridConstraints.gridy = 3;
        getContentPane().add(computeButton, gridConstraints);
        
        computeButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {
               computeButtonActionPerformed(e);
            }
        });
        
        heightTextField.setText("");
        heightTextField.setColumns(3);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 0;
        getContentPane().add(heightTextField, gridConstraints);
        
        weightTextField.setText("");
        weightTextField.setColumns(3);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 1;
        getContentPane().add(weightTextField, gridConstraints);
        
        BMITextField.setText("");
        BMITextField.setColumns(5);
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 2;
        getContentPane().add(BMITextField, gridConstraints);

        BMITextField.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {
               computeButtonActionPerformed(e);
            }
        });
        
        feetLabel.setText("feet");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 0;
        getContentPane().add(feetLabel, gridConstraints);
        
        inchLabel.setText("inches");
        gridConstraints.gridx = 4;
        gridConstraints.gridy = 0;
        getContentPane().add(inchLabel, gridConstraints);

        feetTextField.setText("");
        feetTextField.setColumns(3);
        gridConstraints.gridx = 3;
        gridConstraints.gridy = 0;
        getContentPane().add(feetTextField, gridConstraints);
        
        poundLabel.setText("pounds");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 1;
        getContentPane().add(poundLabel, gridConstraints);

        clearButton.setText("Clear");
        gridConstraints.gridx = 1;
        gridConstraints.gridy = 3;
        getContentPane().add(clearButton, gridConstraints);
        
        exitButton.setText("Exit");
        gridConstraints.gridx = 2;
        gridConstraints.gridy = 3;
        getContentPane().add(exitButton, gridConstraints);
    
        exitButton.addActionListener(new ActionListener(){
            public void actionPerformed(ActionEvent e)
            {
                exitButtonActionPerformed(e);
            }
        });
    }
    public void computeButtonActionPerformed(ActionEvent e)
    {
        double ans, sna, san;
        ans = Double.parseDouble(heightTextField.getText());
        sna = Double.parseDouble(weightTextField.getText());
        
        double bmi = sna / (ans * 2) * 703;
        BMITextField.setText(""+bmi);
    }
    public void exitButtonActionPerformed(ActionEvent e)
    {
        JFrame f;
        f=new JFrame();
        JOptionPane.showMessageDialog(f, "Exiting Module");
    }
    public void exitForm(WindowEvent e)
    {
        JFrame f;
        f=new JFrame();
        JOptionPane.showMessageDialog(f, "Exiting Module");
    }
    public static void main(String[] args)
    {
        new BMI().show();
    }
}
    
    