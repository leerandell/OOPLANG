public class Dog extends Animal
{
    String DogName;
    public Dog()
    {
        
    }
    public String getDogName()
    {
        return DogName;
    }
    public void setDogName(String DogName)
    {
        this.DogName = DogName;
    }
    public Dog(String legs, String color)
    {
        super(legs, color);
        this.DogName = "Madlangtuta";
    }
    public void showInfo()
    {
        System.out.println("The name is " + DogName);
    }
}
