public class InheritanceTest
{
    public static void main(String[] args)
    {
        Dog Dog1 = new Dog();
        Dog1.color = "White";
        Dog1.legs = "2";
        Dog1.DogName = "Madlangtuta";
        Dog1.showInfo();
    }
}
