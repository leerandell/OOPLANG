public class Animal extends InheritanceTest
{
    String color;
    String legs;
    public Animal()
    {
        
    }
    public Animal(String color, String legs)
    {
        this.color = color;
        this.legs = legs;
    }
    public String getColor(String color)
    {
        return color;
    }
    public String getLegs(String legs)
    {
        return legs;
    }
    public void showInfo()
    {
        System.out.println("The color is "+color);
        System.out.println("It has " + legs + " legs.");
    }
}
